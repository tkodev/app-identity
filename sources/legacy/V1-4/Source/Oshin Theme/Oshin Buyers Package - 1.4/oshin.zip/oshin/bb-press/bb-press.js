(function (jQuery) {
	jQuery(document).ready(function() {
		
	});
	jQuery(document).on("update_content", function() {

	});
}(jQuery));