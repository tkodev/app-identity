=== Brankic Photostream Widget ===
Contributors: brankic1979
Donate link: http://themeforest.net/user/Brankic1979/portfolio
Tags: Instagram, Pinterest, Dribbble, Flickr, photostream, photo, image, stream
Requires at least: 3.0
Tested up to: 3.4.1
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Showing photostream from Dribble, Flickr, Instargam or Pinterest

== Description ==

Brankic Photostream plugin displays photos from Flickr, Pinterest, Dribbble or Instagram in your sidebar. Just set username, network and number of photos to show.

Live demo you can see in the sidebar [of our demo site](http://demo.brankic.net/bigbangwp/2012/07/divinum-dare-humanum-accipere/ "Our demo site")

== Installation ==

This section describes how to install the plugin and get it working.


1. Upload brankic-photostream-widget.zip to plugins, like any other plugin, or upload unzipped folder brankic-photostream-widget to wp-content/plugins/
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to Widgets and use Brankic Photostream Widget in the sidebar you want

== Frequently Asked Questions ==

1. for any questions, error report and suggestions please email support@brankic.net or visit http://www.brankic1979.com

== Screenshots ==

1. Sidebar widget

== Changelog ==

= 1.3 =
* Hover color selector jQuery plugin
* Added screenshot

= 1.2 =
* Hover color selector

= 1.1 =
* Some CSS fixes

= 1.0 =
* Initial release

== Upgrade Notice ==

= 1.0 =

