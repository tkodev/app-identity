<?php
	if (!function_exists('be_themes_add_bb_press_styles_and_scripts')) {
		function be_themes_add_bb_press_styles_and_scripts() {
			wp_register_style( 'be-themes-bb-press-css', get_template_directory_uri() . '/bb-press/bb-press.css' );
			wp_enqueue_style( 'be-themes-bb-press-css' );
			wp_register_script( 'be-themes-bb-press-js', get_template_directory_uri() . '/bb-press/bb-press.js', array( 'jquery','be-themes-plugins-js'), FALSE, TRUE );
			wp_enqueue_script( 'be-themes-bb-press-js' );
		}
		add_action( 'wp_enqueue_scripts', 'be_themes_add_bb_press_styles_and_scripts' );
	}
?>